package phase2;

public class WordOccurrence {
	int lineNo;
	 int position;
	 public WordOccurrence(int l, int p) {
		 lineNo = l;
		 position = p;
		 
	 }
	 public int getLineNum() {
		 return lineNo;
	 }
	 public int getPos() {
		 return position;
	 }


}
